<?php
/*
+-------------------------------------------------------------------------------+
	© r107.pro, 2014. Все права защищены.
	Сайт: http://r107.pro, http://osgroup.pro
	Почта: support@r107.pro
	Кодировка: utf8
	Дата: 04.11.2014 05:05:05
	Автор: © Open Source Group
+-------------------------------------------------------------------------------+
	© r107.pro, 2014. All Rights Reserved.
	Site: http://r107.pro, http://osgroup.pro
	Email: support@r107.pro
	Charset: utf8
	Date: 04.11.2014 05:05:05
	Author: © Open Source Group
+-------------------------------------------------------------------------------+
*/

# Файл конфигурации создан автоматически программой установки системы е107


$mySQLserver    = 'localhost';
$mySQLuser      = 'root';
$mySQLpassword  = '123';
$mySQLdefaultdb = 'r107';
$mySQLprefix    = 'r_';
//$mySQLcharset может содержать, только 'utf8' или ''
$mySQLcharset   = 'utf8';

$ADMIN_DIRECTORY     = 'admin/';
$DOCS_DIRECTORY      = 'docs/help/';
$DOWNLOADS_DIRECTORY = 'files/downloads/';
$FILES_DIRECTORY     = 'files/';
$HANDLERS_DIRECTORY  = 'handlers/';
$IMAGES_DIRECTORY    = 'images/';
$LANGUAGES_DIRECTORY = 'languages/';
$PLUGINS_DIRECTORY   = 'plugins/';
$SYSTEM_DIRECTORY    = 'system/';
$THEMES_DIRECTORY    = 'themes/';

?>