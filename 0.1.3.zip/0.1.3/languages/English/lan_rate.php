<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/lan_rate.php $
|     $Revision: 11678 $
|     $Id: lan_rate.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "vote");
define("RATELAN_1", "votes");
define("RATELAN_2", "how do you rate this item?");
define("RATELAN_3", "thank you for your vote");
define("RATELAN_4", "not rated");
define("RATELAN_5", "Rate");

?>