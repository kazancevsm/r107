<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/lan_sitedown.php $
|     $Revision: 11678 $
|     $Id: lan_sitedown.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Site temporarily closed");
define("LAN_SITEDOWN_00", "is temporarily closed");
define("LAN_SITEDOWN_01", "We have temporarily closed the site for some essential maintenance. This shouldn't take too long - please check back soon, apologies for the inconvenience.");
?>