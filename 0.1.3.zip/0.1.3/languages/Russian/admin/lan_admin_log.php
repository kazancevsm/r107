<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Лог Администратора");
define("LAN_ADMINLOG_1", "Дата");
define("LAN_ADMINLOG_2", "Заголовок");
define("LAN_ADMINLOG_3", "Описание");
define("LAN_ADMINLOG_4", "IP пользователя");
define("LAN_ADMINLOG_5", "ID пользователя");
define("LAN_ADMINLOG_6", "Значок информации"); 
define("LAN_ADMINLOG_7", "Сообщение информации"); 
define("LAN_ADMINLOG_8", "Значок уведомления"); 
define("LAN_ADMINLOG_9", "Сообщение уведомления"); 
define("LAN_ADMINLOG_10", "Значок предупреждения"); 
define("LAN_ADMINLOG_11", "Сообщение предупреждения"); 
define("LAN_ADMINLOG_12", "Значок ошибки");
define("LAN_ADMINLOG_13", "Сообщение ошибки"); 
?>