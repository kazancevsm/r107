<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("DBLAN_1", "Не могу прочитать файл БД<br /><br />Убедитесь, что файл <b>core_sql.php</b> находится в дериктории <b>/admin/sql</b>.");
define("DBLAN_2", "Полная проверка");

define("DBLAN_4", "Таблица");
define("DBLAN_5", "Поле");
define("DBLAN_6", "Статус");
define("DBLAN_7", "Записи");
define("DBLAN_8", "Несоответствие");
define("DBLAN_9", "В текущий момент");
define("DBLAN_10", "возможно");
define("DBLAN_11", "Поле утеряно");
define("DBLAN_12", "Дополнительное поле!");
define("DBLAN_13", "Таблица утеряна!");
define("DBLAN_14", "Выберите таблицу(ы) для проверки");
define("DBLAN_15", "Начать проверку");
define("DBLAN_16", "Проверка SQL");
define("DBLAN_17", "Назад");
define("DBLAN_18", "Таблицы");
define("DBLAN_19", "Попытаться исправить");
define("DBLAN_20", "Попытаться исправить таблицы");
define("DBLAN_21", "Исправить выбранные элементы");
define("DBLAN_22", " не читается"); // is not readable
?>