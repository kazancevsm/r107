<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("FOOTLAN_1", "Сайт");
define("FOOTLAN_2", "Главный Администратор");
define("FOOTLAN_3", "Версия");
define("FOOTLAN_4", "сборка");
define("FOOTLAN_5", "Тема Админинпанели");
define("FOOTLAN_6", "Автор:");
define("FOOTLAN_7", "Информация");
define("FOOTLAN_8", "Дата установки");
define("FOOTLAN_9", "Сервер");
define("FOOTLAN_10", "хост");
define("FOOTLAN_11", "Версия PHP");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Информация о сайте");
define("FOOTLAN_14", "Показать документацию");
define("FOOTLAN_15", "Документация");
define("FOOTLAN_16", "База данных");
define("FOOTLAN_17", "Кодировка");
define("FOOTLAN_18", "Тема сайта");
define("FOOTLAN_19", "Текущее время сервера");
define("FOOTLAN_20", "Уровень безопасности");


?>