<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("LAN_CHECK_1", "Проверить/Редактировать языковые файлы");
define("LAN_CHECK_2", "Начать проверку");
define("LAN_CHECK_3", "Проверка ");
define("LAN_CHECK_4", "Файл отсутствует!");
define("LAN_CHECK_5", "Фраза отсутствует!");
define("LAN_CHECK_7", "фраза");
define("LAN_CHECK_8", "Файл отсутствует...");
define("LAN_CHECK_9", " файлов отсутствует...");
define("LAN_CHECK_10", "Критическая ошибка: ");
define("LAN_CHECK_11", "Нет отсутствующих файлов !");
define("LAN_CHECK_12", "Файл ошибочный...");
define("LAN_CHECK_13", " ошибочных файлов...");
define("LAN_CHECK_14", "Все существующие файлы правильны !");
define("LAN_CHECK_15", "Найдены недопустимые символы перед '<?php'");
define("LAN_CHECK_16", "Оригинальный файл");
define("LAN_CHECK_17", "Произошла проблема записи во время попытки сохранения файла.");
define("LAN_CHECK_18", "Языковые файлы в стандартном формате НЕдоступны для этого плагина/темы.");
define("LAN_CHECK_19", "Найдены не UTF-8 символы");
define("LAN_CHECK_20", "Сгененрировать Языковой Пакет");
define("LAN_CHECK_21", "Проверить заново");
define("LAN_CHECK_22", "Тема");
define("LAN_CHECK_23", "Обнаружено ошибок");
define("LAN_CHECK_24", "Итого");
define("LAN_CHECK_25", "Темы");
define("LAN_CHECK_26", "Файл");

?>