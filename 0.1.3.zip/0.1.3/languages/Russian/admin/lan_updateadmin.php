<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("UDALAN_1", "Ошибка - пожалуйста, переподтвердите");
define("UDALAN_2", "Настройки обновлены");
define("UDALAN_3", "Настройки обновлены для");
define("UDALAN_4", "Имя");
define("UDALAN_5", "Пароль");
define("UDALAN_6", "Повторите пароль");
define("UDALAN_7", "Смена пароля");
define("UDALAN_8", "Обновление пароля для");
?>