<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Баннеры");

define("BANNERLAN_16", "Логин: ");
define("BANNERLAN_17", "Пароль: ");
define("BANNERLAN_18", "Продолжить");
define("BANNERLAN_19", "Введите логин и пароль клиента для продолжения");
define("BANNERLAN_20", "Извините, такие данные в БД не обнаружены. Пожалуйста, свяжитесь с администратором сайта для более корректной информации.");
define("BANNERLAN_21", "Статистика Баннеров");
define("BANNERLAN_22", "Клиент");
define("BANNERLAN_23", "ID баннера");
define("BANNERLAN_24", "Переходов");
define("BANNERLAN_25", "Нажатий %");
define("BANNERLAN_26", "Показов");
define("BANNERLAN_27", "Показов приобретено");
define("BANNERLAN_28", "Показов истрачено");
define("BANNERLAN_29", "Нет баннеров");
define("BANNERLAN_30", "Неограниченно");
define("BANNERLAN_31", "Неприменимо");
define("BANNERLAN_32", "Да");
define("BANNERLAN_33", "Нет");
define("BANNERLAN_34", "Окончание:");
define("BANNERLAN_35", "Переходов с IP-адресов");
define("BANNERLAN_36", "Активно:");
define("BANNERLAN_37", "Начало:");
define("BANNERLAN_38", "Ошибка");

?>