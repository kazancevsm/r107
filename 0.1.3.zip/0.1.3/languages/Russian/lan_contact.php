<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/
define("PAGE_NAME",     "Обратная связь");
define("LANCONTACT_01", "Контакты");
define("LANCONTACT_02", "Написать нам");
define("LANCONTACT_03", "Ваше имя:");
define("LANCONTACT_04", "E-mail адрес:");
define("LANCONTACT_05", "Тема сообщения:");
define("LANCONTACT_06", "Сообщение:");
define("LANCONTACT_07", "Отправить копию этого сообщения на ваш собственный почтовый ящик ");
define("LANCONTACT_08", "Отправить");
define("LANCONTACT_09", "Ваше сообщение было отправлено.");
define("LANCONTACT_10", "Произошла ошибка во время отправки вашего сообщения.");
define("LANCONTACT_11", "Вы указали, некорректный e-mail.\\nПожалуйста, проверьте его и попробуйте заново.");
define("LANCONTACT_12", "Ваше сообщение слишком короткое.");
define("LANCONTACT_13", "Пожалуйста, укажите тему сообщения."); 
define("LANCONTACT_14", "Отправить сообщение для:");
define("LANCONTACT_15", "Введен неправильный код");
define("LANCONTACT_16", "Введите код");

?>