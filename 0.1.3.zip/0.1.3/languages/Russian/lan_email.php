<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Электронная почта"); }

define("LAN_EMAIL_1", "От:");
define("LAN_EMAIL_2", "IP отправителя:");
define("LAN_EMAIL_3", "Послать по e-mail от ");
define("LAN_EMAIL_4", "Отправить e-mail");
define("LAN_EMAIL_5", "Отправить другу с помощью Email");
define("LAN_EMAIL_6", "Я подумал, что вас заинтересует эта информация с"); //I thought you might be interested in this item from
define("LAN_EMAIL_7", "отпавить с помощью e-mail кому-нибудь");
define("LAN_EMAIL_8", "Комментарий");
define("LAN_EMAIL_9", "К сожалению, произошла ошибка, и письмо не было отправлено");
define("LAN_EMAIL_10", "Письмо отправлено на");
define("LAN_EMAIL_11", "Письмо отправлено");
define("LAN_EMAIL_12", "Ошибка");
define("LAN_EMAIL_13", "Отпавить статью другу с помощью e-mail");
define("LAN_EMAIL_14", "Отправить новость другу с помощью e-mail");
define("LAN_EMAIL_15", "Имя пользователя: ");
define("LAN_EMAIL_106", "Введен неправильный адрес e-mail");
define("LAN_EMAIL_185", "Отправить статью");
define("LAN_EMAIL_186", "Отправить новость");
define("LAN_EMAIL_187", "Адрес e-mail для отправки");
define("LAN_EMAIL_188", "Я думаю, что Вас заинтересует эта новость с сайта");
define("LAN_EMAIL_189", "Я думаю, что Вас заинтересует эта статья на сайте");
define("LAN_EMAIL_190", "Введите изображенный код");


?>