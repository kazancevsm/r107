<?php
define('LAN_LOGIN_ADMINPANEL', 'Админпанель');
define("LAN_LOGIN_FORGOTPAS", "Забыли пароль?");
define("LAN_LOGIN_IMAGECODE", "Введите изображенный код");
define('LAN_LOGIN_LISTNEW', 'Список новых');
define("LAN_LOGIN_LOGIN", "Войти");
define('LAN_LOGIN_LOGOUT', 'Выйти');
define('LAN_LOGIN_PROFILE', 'Профиль');
define("LAN_LOGIN_PROTECTED", "Защищённый сервер");
define("LAN_LOGIN_REMEMBER", "Запомнить меня");
define('LAN_LOGIN_SETTINGS', 'Настройки');
define('LAN_LOGIN_SING', 'Войти');
define("LAN_LOGIN_USERDETAIL", "Для получения доступа, пожалуйста, сообщите подробности.");
define("LAN_LOGIN_USERNAME", "Имя пользователя");
define("LAN_LOGIN_USERPASSWORD", "Пароль");
define('LAN_LOGIN_REG', 'Регистрация');
define("LAN_LOGIN_USERNEW", "Зарегистрироваться как новый пользователь");
define('LAN_LOGIN_WELCOME', 'Приветствую, ');

define("LAN_LOGIN_MASSAGE1", "Неверный вход на сайт. Введенная информация не соответствует ни одному зарегистрированному пользователю. Проверьте, не включен ли CAPS LOCK имя и пароль чувствительны к регистру");
define("LAN_LOGIN_MASSAGE2", "Вы оставили пустым требуемое поле(я)");
define("LAN_LOGIN_MASSAGE3", "Вы не активировали вашу учётную запись. Вы должны были получить сообщение на e-mail с инструкциями, как подтвердить вашу учетную запись. Если вы его не получили, пожалуйста, щелкните <a href='".e_BASE."signup.php?resend'>здесь</a>.");
define("LAN_LOGIN_MASSAGE4", "Введен неверный код.");
define("LAN_LOGIN_MASSAGE5", "Такая комбинация имени/пароля уже используется.");
define("LAN_LOGIN_MASSAGE6", "Пользователь пытался войти с неизвестным именем");
define("LAN_LOGIN_MASSAGE7", "Пользователь пытался войти с неправильным паролем");
define("LAN_LOGIN_MASSAGE8", "Пользователь пытался войти с комбинацией имени/пароля, которая уже использовалась");
define("LAN_LOGIN_MASSAGE9", "Пароль пользователя (хешированный)");
define("LAN_LOGIN_MASSAGE10", "Авто-запрет: Более 10 неудавшихся попыток входа");
define("LAN_LOGIN_MASSAGE11", "> 10 неудавшихся попыток входа");
?>