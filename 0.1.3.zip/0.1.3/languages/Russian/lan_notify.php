<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Регистрация пользователя");
define("NT_LAN_UV_1", "Регистрация подтверждена");
define("NT_LAN_UV_2", "ID пользователя: ");
define("NT_LAN_UV_3", "Имя пользователя: ");
define("NT_LAN_UV_4", "IP пользователя: ");
define("NT_LAN_LI_1", "Пользователь вошел");
define("NT_LAN_LO_1", "Пользователь вышел");
define("NT_LAN_LO_2", " вышел с сайта");
define("NT_LAN_FL_1", "Запрет флуда");
define("NT_LAN_FL_2", "IP адрес заблокирован из-за флуда");
define("NT_LAN_SN_1", "Новость представлена на рассмотрение");
define("NT_LAN_NU_1", "Обновлена");
define("NT_LAN_ND_1", "Новость удалена");
define("NT_LAN_ND_2", "ID удаленной новости");
?>