<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "Рейтинг пользователей форума"); //Top Forum Posters
define("TOP_LAN_1", "Имя пользователя");
define("TOP_LAN_2", "Сообщений");
define("TOP_LAN_3", "Рейтинг комментаторов");
define("TOP_LAN_4", "Комментариев");
define("TOP_LAN_5", "Рейтинг чата");
define("TOP_LAN_6", "Рейтинг");

//v.616
define("LAN_1", "Тема");
define("LAN_2", "Отправитель"); //Poster
define("LAN_3", "Просмотры");
define("LAN_4", "Ответы");
define("LAN_5", "Последнее сообщение");
define("LAN_6", "Темы");
define("LAN_7", "Самые активные темы");
define("LAN_8", "Рейтинг отправителей"); //Top Posters


?>