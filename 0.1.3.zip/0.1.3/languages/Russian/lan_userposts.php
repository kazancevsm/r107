<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Сообщения пользователей");
define("UP_LAN_0", "Все сообщения форума для ");
define("UP_LAN_1", "Все комментарии от ");
define("UP_LAN_2", "Тема");
define("UP_LAN_3", "Просмотры"); //Views
define("UP_LAN_4", "Ответы");
define("UP_LAN_5", "Последнее сообщение");
define("UP_LAN_6", "Темы");
define("UP_LAN_7", "Нет комментариев");
define("UP_LAN_8", "Нет сообщений");
define("UP_LAN_9", " на ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Сообщено "); //Posted on
define("UP_LAN_12", "Поиск"); //Search
define("UP_LAN_13", "Комментарии");
define("UP_LAN_14", "Сообщения форума");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "IP адрес");
?>