<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/
	
define("CLOCK_AD_L1", "Настройки часов сохранены");
define("CLOCK_AD_L2", "Заголовок");
define("CLOCK_AD_L3", "Обновить настройки меню");
define("CLOCK_AD_L4", "Настройки меню часов");
define("CLOCK_AD_L5", "ДП/ПП");
define("CLOCK_AD_L6", "Если отмечено, будет отображать время в формате (00-12 формат ДП/ПП). Если не отметить, будете отображен' формат 00-24");
define("CLOCK_AD_L7", "Преффикс даты");
define("CLOCK_AD_L8", "Если ваш язык требует слова перед датой (например, 'le' для французского или 'den' для немецкого), используйте это поле. Если не требует - оставьте пустым.");
define("CLOCK_AD_L9", "Суффикс 1");
define("CLOCK_AD_L10", "Суффикс 2");
define("CLOCK_AD_L11", "Суффикс 3");
define("CLOCK_AD_L12", "Суффикс 4 и дальше");
define("CLOCK_AD_L13", "Если ваш язык требует ставить суффикс после номера даты, заполните эти поля нужными суффиксами (Пример: 'е' для 1, 'е' для 2, и т.д.). Если не требует - оставьте пустым.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>