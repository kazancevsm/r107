<?php
header ("Location:vtrade.php");
?>
