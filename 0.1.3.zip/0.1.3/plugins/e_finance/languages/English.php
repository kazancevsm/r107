<?php
//admin_menu.php
define("_MYSTORE01","Main Configuration");
define("_MYSTORE02","Add/Manage Categories");
define("_MYSTORE03","Add/Manage Products");
define("_MYSTORE04","View Sales Lists");
define("_MYSTORE05","Visit myTipper.com");
define("_MYSTORE06","myStore Management Menu");

//admincat.php
define("_MYSTORE07","Edit:");
define("_MYSTORE08","Delete:");
define("_MYSTORE09","myStore Configuration");
define("_MYSTORE10","Information Missing");
define("_MYSTORE11","Not All Information was Entered");
define("_MYSTORE12","Category Name:");
define("_MYSTORE13","Category Description:");
define("_MYSTORE14","Manage/Add Categories");
define("_MYSTORE15","Manage/Add Products");
define("_MYSTORE16","myStore Management");

//adminprods.php
define("_MYSTORE17","Product Name:");
define("_MYSTORE18","Product Description:");
define("_MYSTORE19","Product Price:");
define("_MYSTORE20","Postage Price:");
define("_MYSTORE21","Detailed Description:");
define("_MYSTORE22","Small Image:");
define("_MYSTORE23","Large Image:");
define("_MYSTORE24","myStore Edit/Delete");
define("_MYSTORE25","Fields Not Completed");

//cart.php
$webaddy = SITEURL."signup.php";
define("_MYSTORE26","Not Logged in");
define("_MYSTORE27","You must be registered and logged in to Checkout </br><a href=$webaddy>Click here to register</a></br>");
define("_MYSTORE28","You have already added this item to your cart");
define("_MYSTORE29","Shopping Cart");
define("_MYSTORE30","Your Shopping Cart is Currently Empty");
define("_MYSTORE31","Click Here To Go back to the Categories");
define("_MYSTORE32","Description");
define("_MYSTORE33","Cost Per Item");
define("_MYSTORE34","Remove?");
define("_MYSTORE35","This Item Doesnt Apper to Exist!!");
define("_MYSTORE36","Postage & Handling:");
define("_MYSTORE37","Total:");
define("_MYSTORE38","Continue Shopping");
define("_MYSTORE39","Online Store");
define("_MYSTORE40","Remove Item");
define("_MYSTORE73","QTY");
define("_MYSTORE74","SKU");

//myprods.php
define("_MYSTORE41","There are currently no products under this category, please check back later. <a href=myStore.php>Back to Categories</a>");
define("_MYSTORE42","Add to Cart");
define("_MYSTORE43","Go To Your Shopping Cart");

//myStore.php
define("_MYSTORE44","The store currently has no categories configured, please contact the Admin and ask them to configure the categories.");
define("_MYSTORE45","Product Categories");

//myStore_config.php
define("_MYSTORE46","Store Admin Email:");
define("_MYSTORE47","Business (PayPal) Email:");
define("_MYSTORE48","Postage and Handling:");
define("_MYSTORE49","Per Item:");
define("_MYSTORE50","Free:");
define("_MYSTORE51","Minimum Postage Price:");
define("_MYSTORE52","If free P&H enter 0.00");
define("_MYSTORE53","Maximum Postage Price:");
define("_MYSTORE72","Currency:");

//notify.php
define("_MYSTORE55","A Purchase Has been Completed from your Site");
define("_MYSTORE56","Follow this link to view purchase details: $webaddress \n\n The Payment Status is:$payment_status\n\nPlease contact the user to obtain delivery details.\n\n\nhttp://www.myTipper.com");
define("_MYSTORE57","Your Purcahse from");
define("_MYSTORE58","The purchase you made did not get paid correctly, the Paypal Payment Status is:$payment_status, \n\n please disucss with paypal or the site Admin for further information.");
define("_MYSTORE59","Failed");

//sales.php
define("_MYSTORE60","Purchase From");
define("_MYSTORE61","myStore Pending Sales");
define("_MYSTORE62","myStore Old Sales");

//sdetail.php
define("_MYSTORE63","Shopping Cart");
define("_MYSTORE64","Description");
define("_MYSTORE65","Item");
define("_MYSTORE66","Cost Per Item");
define("_MYSTORE67","Status");
define("_MYSTORE68","myStore Purchase for");
define("_MYSTORE69","This Item Doesnt Apper to Exist!!");

//showpic.php
define("_MYSTORE70","Go Back to The Product");
define("_MYSTORE71","Detailed Product Details");

//New Additions
define("_MYSTOREp","Sub-Category of:");
define("_MYSTORE_DEL","The Category Has Been Deleted");
define("_MYSTOREAD"," Has Been Added to the Database");
define("_MYSTORE_com","Category Added");
define("_MYSTORE_nad","There Was an error please try again");
define("_MYSTORE_cur","Current Parent: ");
define("_MYSTOREED"," Has Been Edited Successfully");
define("_MYSTOREcat","Category: ");
define("_MYSTOREempt","You have not yet added any items to your Shopping Cart or the Shopping Cart has expired (Contents of the Shopping Cart will be removed fromt he cart after 24 hours");
?>