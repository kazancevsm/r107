$('a href').click(function(e){
    e.preventDefault();
  });
});