 <script type="text/javascript">
   function test(){
    alert("udelit");
   }
   </script>