<?php
$day="1, 2, 3";
$exp_d = explode (',',$day);
echo $exp_d[0];
//$day=array(sdf,ghj);

//echo $day[0];
//echo gettype($arr[0]), gettype($multi).",".gettype($cat)."
?>