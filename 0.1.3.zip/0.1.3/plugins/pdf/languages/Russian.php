<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Поддержка создания PDF-документов");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Плагин готов к использованию.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "Настройки PDF");
define("PDF_LAN_3", "вкл");
define("PDF_LAN_4", "выкл");
define("PDF_LAN_5", "отступ слева");
define("PDF_LAN_6", "отступ справа");
define("PDF_LAN_7", "отступ сверху");
define("PDF_LAN_8", "шрифт");
define("PDF_LAN_9", "размер шрифта по умолчанию");
define("PDF_LAN_10", "размер шрифта в имени сайта");
define("PDF_LAN_11", "размер шрифта для url страницы");
define("PDF_LAN_12", "размер шрифта для номера страницы");
define("PDF_LAN_13", "показать лого в pdf-документе?");
define("PDF_LAN_14", "показать имя сайта в pdf-документе?");
define("PDF_LAN_15", "показать url в pdf-документе?");
define("PDF_LAN_16", "показать номера страниц в pdf-документе?");
define("PDF_LAN_17", "обновить");
define("PDF_LAN_18", "Настройки PDF успешно обновлены");
define("PDF_LAN_19", "Страница");
define("PDF_LAN_20", "сообщения об ошибках");

?>