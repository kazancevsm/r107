 <?php
 
 define("SITEBUTTON_MENU_L1", "Site Button");
 define("SITEBUTTON_MENU_L2", "Code:<br>");
 ?>