<?php

define("SITEBUTTON_MENU_L1", "Кнопка сайта");
define("SITEBUTTON_MENU_L2", "Код вставки:<br>");
?>