<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_e107_update.php $
|     $Revision: 11678 $
|     $Id: lan_e107_update.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Action");
define("LAN_UPDATE_3", "Not Needed");

define("LAN_UPDATE_5", "Update available");
define("LAN_UPDATE_7", "Executed");
define("LAN_UPDATE_8", "Update from");
define("LAN_UPDATE_9", "to");
define("LAN_UPDATE_10", "Available Updates");
define("LAN_UPDATE_11", ".617 to .7 Update Continued");
define("LAN_UPDATE_12", "One of your tables contains duplicate entries.");


?>