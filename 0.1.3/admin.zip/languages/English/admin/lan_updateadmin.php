<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_updateadmin.php $
|     $Revision: 11678 $
|     $Id: lan_updateadmin.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Error - please re-submit");
define("UDALAN_2", "Settings updated");
define("UDALAN_3", "Settings updated for");
define("UDALAN_4", "Name");
define("UDALAN_5", "Password");
define("UDALAN_6", "Re-type password");
define("UDALAN_7", "Change password");
define("UDALAN_8", "Password updated for");

?>