<?php
define("LAN_PREF_1", "r107 Powered Website");
define("LAN_PREF_2", "r107 Website System");
define("LAN_PREF_3", "This site is powered by <a href=&quot;http://r107.pro/&quot; rel=&quot;external&quot;>r107</a>, which is released under the terms of the <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL License.<br />
			Build of the present version of system and russian localization are prepared by a command OSGroup.pro<br />
			Author: Sergey Kazancev [Sunout]<br />
			© <a href='http://r107.pro'>r107.pro</a> 2014-".date('Y').". All Rights Reserved.");
define("LAN_PREF_4", "censored");
define("LAN_PREF_5", "Forums");

?>