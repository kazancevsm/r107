<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("MESSLAN_1", "Принятые сообщения");
define("MESSLAN_2", "Удалить сообщение");
define("MESSLAN_3", "Сообщение удалено.");
define("MESSLAN_4", "Удалить все сообщения");
define("MESSLAN_5", "Подтвердите");
define("MESSLAN_6", "Все сообщения удалены.");
define("MESSLAN_7", "Нет сообщений.");
define("MESSLAN_8", "Тип сообщений");
define("MESSLAN_9", "Сообщено");
define("MESSLAN_10", "Сообщил ");
define("MESSLAN_11", "открыть в новом окне");
define("MESSLAN_12", "Сообщение");
define("MESSLAN_13", "Ссылка");
?>