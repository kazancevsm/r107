<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("NT_LAN_FT_1", "События");
define("NT_LAN_FO_1", "Тема добавлена");
define("NT_LAN_MP_1", "Сообщение добавлено");
define("NT_LAN_FD_1", "Тема удалена");
define("NT_LAN_FP_1", "Сообщение удалено");
define("NT_LAN_FM_1", "Тема перемещена");
define("NT_LAN_FO_3", "Тема создана");
define("NT_LAN_FO_4", "Название форума");
define("NT_LAN_FO_5", "Субъект");
define("NT_LAN_FO_6", "Сообщение");
define("NT_LAN_FO_7", "Новая тема создана");
define("NT_LAN_MP_3", "Сообщение создано");
define("NT_LAN_MP_4", "Название форума");
define("NT_LAN_MP_6", "Сообщение");
define("NT_LAN_MP_7", "Новое сообщение создано");
define("NT_LAN_FD_3", "Тема создана");
define("NT_LAN_FD_4", "Название форума");
define("NT_LAN_FD_5", "Субъект");
define("NT_LAN_FD_6", "Сообщение");
define("NT_LAN_FD_7", "Тема удалена");
define("NT_LAN_FD_8", "Тема удалена");
define("NT_LAN_FP_3", "Сообщение создано");
define("NT_LAN_FP_4", "Название форума");
define("NT_LAN_FP_6", "Сообщение");
define("NT_LAN_FP_7", "Сообщение удалено");
define("NT_LAN_FP_8", "Сообщение удалено");
define("NT_LAN_FM_3", "Тема создана");
define("NT_LAN_FM_4", "Старый субъект");
define("NT_LAN_FM_5", "Новый субъект");
define("NT_LAN_FM_6", "Старое название форума (источник)");
define("NT_LAN_FM_7", "Новое название форума (назначение)");
define("NT_LAN_FM_8", "Тема перемещена");
define("NT_LAN_FM_9", "Тема перемещена");


?>