<?php
/*
+ ------------------------------------------------------------------------------+
|	Русский языковой пакет для e107 0.7.26										|
|	Сайт: http://www.e107club.ru												|
|	Почта: translate@e107club.ru												|
|	Ревизия: 1.0																|
|	Кодировка: utf-8															|
|	Дата: 25.09.2011 05:05:05													|
|	Автор: © Кадников Александр	[Predator]										|
|	© е107 Клуб 2010-2011. Все права защищены.									|
|																				|
|	Russian Language Pack for e107 0.7.26										|
|	Site: http://www.e107club.ru												|
|	Email: translate@e107club.ru												|
|	Revision: 1.0																|
|	Charset: utf-8																|
|	Date: 25.09.2011 05:05:05													|
|	Author: © Alexander Kadnikov [Predator]										|
|	© е107 Club 2010-2011. All Rights Reserved.									|
+-------------------------------------------------------------------------------+
*/

define("e_PAGETITLE", "Статистика форума");

define("FSLAN_1", "Общая");
define("FSLAN_2", "Форум открыт");
define("FSLAN_3", "Открыт для ");
define("FSLAN_4", "Всего сообщений");
define("FSLAN_5", "Разделы форума");
define("FSLAN_6", "Ответы форума");
define("FSLAN_7", "Просмотров тем форума");
define("FSLAN_8", "Размер БД (только таблицы форума)");
define("FSLAN_9", "Средняя длина ряда в таблице форума");
define("FSLAN_10", "Наиболее активные разделы");
define("FSLAN_11", "Ранг");
define("FSLAN_12", "Раздел");
define("FSLAN_13", "Ответы");
define("FSLAN_14", "Начато ");
define("FSLAN_15", "Дата");
define("FSLAN_16", "Наиболее просматриваемые разделы");
define("FSLAN_17", "Просмотров");
define("FSLAN_18", "Самые активные пользователи");
define("FSLAN_19", "Имя");
define("FSLAN_20", "Сообщений");
define("FSLAN_21", "Больше всех начали разделов");
define("FSLAN_22", "Лучшие ответы");
define("FSLAN_23", "Статистика Форума");
define("FSLAN_24", "Среднее кол-во сообщений в день");

?>