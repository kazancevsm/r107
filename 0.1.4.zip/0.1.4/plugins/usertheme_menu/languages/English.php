<?php

define('LAN_UMENU_THEME_1', 'Set Theme');
define('LAN_UMENU_THEME_2', 'Select Theme');
define('LAN_UMENU_THEME_3', 'users:');
define('LAN_UMENU_THEME_4', 'Enable those themes which users may select');
define('LAN_UMENU_THEME_5', 'Update');
define('LAN_UMENU_THEME_6', 'Themes available to users');
define('LAN_UMENU_THEME_7', 'Class which can select themes');
	
?>