<?php
# Version file

if (!defined('e107_INIT')) { exit; }
$e107info['e107_version'] = "0.1.4 Standart Assembly <br />The author of this Assembly: <a href='http://webmaster.slog.su'>Open Source Group</a>";

?>